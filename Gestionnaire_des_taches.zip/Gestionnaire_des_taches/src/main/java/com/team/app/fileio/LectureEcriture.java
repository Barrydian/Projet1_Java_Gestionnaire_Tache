/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.team.app.fileio;

import com.team.app.entities.Membre;
import com.team.app.entities.Tache;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MyPC
 */
public class LectureEcriture {
    public static final String FICHIER_MEMBRES = "membres.txt";
    public static final String FICHIER_TACHES = "taches.txt";
    
    public static List<Membre> getListMemberFromFile() {
        List<Membre> list = new ArrayList<>();
        try {                                
            FileInputStream fin = new FileInputStream(FICHIER_MEMBRES);
            ObjectInputStream objIn = new ObjectInputStream(fin);
            list = (ArrayList<Membre>) objIn.readObject();
        } catch (Exception ex) {
            System.out.println("echec de la lecture du fichier membre " + ex.getMessage());
        }
        return list;
    }
    
    public static List<Tache> getListTaskFromFile() {
        List<Tache> list = new ArrayList<>();
        try {                                
            FileInputStream fin = new FileInputStream(FICHIER_TACHES);
            ObjectInputStream objIn = new ObjectInputStream(fin);
            list = (ArrayList<Tache>) objIn.readObject();
        } catch (Exception ex) {
            System.out.println("echec de la lecture du fichier tache " + ex.getMessage());
        }
        return list;
    }
    
    public static void writeListMemberToFile(List<Membre> list) {
        try {
            FileOutputStream fout = new FileOutputStream(FICHIER_MEMBRES);
            ObjectOutputStream objOut = new ObjectOutputStream(fout);
            objOut.writeObject(list);
        } catch (Exception ex) {
            System.out.println("echec d'ecriture dans le fichier membre" + ex.getMessage());
        }
    }
    
    public static void writeListTaskToFile(List<Tache> list) {
        try {
            FileOutputStream fout = new FileOutputStream(FICHIER_TACHES);
            ObjectOutputStream objOut = new ObjectOutputStream(fout);
            objOut.writeObject(list);
        } catch (Exception ex) {
            System.out.println("echec d'ecriture dans le fichier tache " + ex.getMessage());
        }
    }
}
