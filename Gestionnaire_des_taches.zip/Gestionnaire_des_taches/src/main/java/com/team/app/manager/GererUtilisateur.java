/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.team.app.manager;

import com.team.app.entities.Membre;
import com.team.app.entities.Menu;
import com.team.app.entities.Tache;
import com.team.app.enumeration.Operation;
import com.team.app.enumeration.Resultats;
import com.team.app.fileio.LectureEcriture;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author MyPC
 */
public class GererUtilisateur {

    private Scanner sc = new Scanner(System.in);
    private static final List<Membre> listMember = GererMembre.getInstance().getmListMember();
    private static final List<Tache> listTask = GererTaches.getInstance().getmListTask();

    public void runSoftware() {
        int choice;
        do {
            Menu.showUserMenu();
            choice = Menu.chooseUserMenu();
            processQuery(choice);
        } while (true);
    }

    private boolean askContinueQuery() {
        System.out.print("\nVoulez-vous continuer en tant qu'utilisateur<O/N>: ");
        String query = sc.nextLine();
        boolean isInChoosen = query.equalsIgnoreCase("O");
        return isInChoosen;
    }

    /**
     *
     * @param choice is in restrict and always valid
     */
    private void processQuery(int choice) {
        boolean isInModify;
        String query;
        switch (choice) {
            case Menu.MODIFIER_MEMBRE:
                do {
                    GererUtilisateurUtil.modifyMember();
                    System.out.print("\nContinuer modifier <CREER, SUPPRIMER, AJOUTER, MODIFIER> Membre <O/N>: ");
                    query = sc.nextLine();
                    isInModify = query.equalsIgnoreCase("O");
                } while (isInModify);
                break;

            case Menu.MODIFIER_TACHE:
                do {
                    GererUtilisateurUtil.modifyTask();
                    System.out.print("\nContinuer modifier <CREER, SUPPRIMER, AJOUTER, MODIFIER> Tache <o/n>: ");
                    query = sc.nextLine();
                    isInModify = query.equalsIgnoreCase("O");
                } while (isInModify);
                break;

            case Menu.ASSIGN_TACHE_AU_MEMBRE:
                do {
                    GererUtilisateurUtil.assignTaskToMember();
                    System.out.print("\nVoulez-vous continuer à assigner les tâches? <O/N>: ");
                    query = sc.nextLine();
                    isInModify = query.equalsIgnoreCase("O");
                } while (isInModify);
                break;

            case Menu.RECHERCH_VOIR_TACHE_PAR_ID_DU_MEMBRE:
                do {
                    GererUtilisateurUtil.displayAllTaskByMemberId();
                    System.out.print("\nVoulez-vous continuer à rechercher et afficher les membres par ID? <O/N>: ");
                    query = sc.nextLine();
                    isInModify = query.equalsIgnoreCase("O");
                } while (isInModify);
                break;

            case Menu.RECHERCH_VOIR_TACHE_PAR_STATUS:
                do {
                    GererUtilisateurUtil.displayAllTaskByStatus();
                    System.out.print("\nVoulez-vous continuer à rechercher et afficher les tâches par etat? <O/N>: ");
                    query = sc.nextLine();
                    isInModify = query.equalsIgnoreCase("O");
                } while (isInModify);
                break;

            case Menu.QUITTER_LE_PROGRAMME:
                LectureEcriture.writeListMemberToFile(listMember);
                LectureEcriture.writeListTaskToFile(listTask);
                System.exit(0);
                break;

            default:
                System.out.println(Operation.ACTION_USER + " " + Resultats.ECHEC);
                break;
        }
    }
}
