/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.team.app.manager;

import com.team.app.entities.Membre;
import com.team.app.entities.Menu;
import com.team.app.enumeration.AtributMembre;
import com.team.app.enumeration.Resultats;
import com.team.app.fileio.LectureEcriture;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import static com.team.app.enumeration.AtributMembre.NOM;
import java.lang.reflect.Member;

/**
 *
 * @author MyPC
 */
public class GererMembre implements GererOperations {

    private static int id = 1;
    private Scanner sc = new Scanner(System.in);
    private final List<Membre> mListMember = LectureEcriture.getListMemberFromFile();
    private final List<Membre> mListCreatedMember = new ArrayList<>();
    private final static GererMembre memberManager = new GererMembre();

    public static GererMembre getInstance() {
        return memberManager;
    }

    private GererMembre() {
    }

    @Override
    public boolean creer() {
        Membre member = makeNewMember();
        mListCreatedMember.add(member);
        return true;
    }

    private Membre makeNewMember() {
        System.out.print("\nEntrer le nom du membre: ");
        String name = sc.nextLine();
        return new Membre(id++, name);
    }

    @Override
    public boolean modifier(int id) {
        boolean result = true;
        Membre member = findMemberById(id);
        if (member != null) {
            boolean isInEdit;
            do {
                Resultats captureResult = editAttribute(member, NOM);
                if (captureResult == Resultats.ANNULEE) {
                    break;
                }
                isInEdit = askContinueChangeName();
            } while (isInEdit);
        } else {
            result = false;
        }
        return result;
    }

    private boolean askContinueChangeName() {
        System.out.print("\nVoulez encore modifier <y/n>: ");
        String querry = sc.nextLine();
        boolean isInEdit = querry.equalsIgnoreCase("y");
        return isInEdit;
    }

    private Resultats editAttribute(Membre member, AtributMembre attr) {
        Resultats resultManager = Resultats.ECHEC;
        if (attr == NOM) {
            String newName = getNewName();
            if (newName.equals("")) {
                resultManager = Resultats.ANNULEE;
            } else {
                member.setNom(newName);
            }
        }
        return resultManager;
    }

    private String getNewName() {
        System.out.println("\nTapez entrer pour annuler la modification.");
        System.out.print("Entrer le nouveau nom : ");
        String newName = sc.nextLine();
        return newName;
    }

    @Override
    public boolean supprimer(int id) {
        boolean result;
        Membre member = findMemberById(id);
        if (member != null) {
            mListMember.remove(member);
            result = true;
        } else {
            result = false;
        }
        return result;
    }

    private Membre findMemberById(int id) {
        for (Membre member : mListMember) {
            if (member.getId() == id) {
                return member;
            }
        }
        return null;
    }

    @Override
    public boolean Ajouter() {
        boolean isEmptyMember = displayListCreateMember();
        //id always exist to make member not null
        if (!isEmptyMember) {
            int id = chooseCreatedMemberById();
            Membre member = findCreateMemberById(id);
            mListCreatedMember.remove(member);
            mListMember.add(member);
            
        }
        return true;
    }

    private boolean displayListCreateMember() {
        boolean isEmptyMember = mListCreatedMember.isEmpty();
        if (isEmptyMember) {
            System.out.println("\nMembre non crée");
        } else {
            System.out.println("\n Liste des membres");
            for (Membre member : mListCreatedMember) {
                System.out.println(member.toString());
            }
        }
        return isEmptyMember;
    }

    private int chooseCreatedMemberById() {
        System.out.println("Choisir un membre par son ID");
        Membre firstMember = mListCreatedMember.get(0);
        Membre lastMember = mListCreatedMember.get(mListCreatedMember.size() - 1);
        int id = Menu.chooseMenu(firstMember.getId(), lastMember.getId());
        return id;
    }

    private Membre findCreateMemberById(int id) {
        for (Membre member : mListCreatedMember) {
            if (member.getId() == id) {
                return member;
            }
        }
        return null;
    }

    public void addMember(Membre member) {
        mListMember.add(member);
    }

    public void displayAllMember() {
        for (Membre member : mListMember) {
            System.out.println(member.toString());
        }
    }

    public Membre getMemberById(int id) {
        for (Membre member : mListMember) {
            if (member.getId() == id) {
                return member;
            }
        }
        return null;
    }

    public int getTotalMember() {
        return mListMember.size();
    }

    public List<Membre> getmListMember() {
        return mListMember;
    }
}
