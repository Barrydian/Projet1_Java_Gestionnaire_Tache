/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.team.app.entities;

import java.util.Scanner;

/**
 *
 * @author MyPC
 */
public class Menu {
    public static final int TACHE_STATUT_NEW = 1;
    public static final int STATUS_TACHE_EN_COURS = 2;
    public static final int TACHE_STATUT_TERMINER = 3;
    public static final int TACHE_STATUT_QUITTER = 4;
    
    public static final int MODIFIER_CREATION = 1;    
    public static final int MODIFIER_EDITION = 2;    
    public static final int MODIFIER_SUPPRESSION = 3;    
    public static final int MODIFIER_AJOUT = 4;    
    public static final int MODIFIER_QUITTER = 5;    
    
    public static final int MODIFIER_TACHE = 1;
    public static final int MODIFIER_MEMBRE = 2;
    public static final int ASSIGN_TACHE_AU_MEMBRE = 3;
    public static final int RECHERCH_VOIR_TACHE_PAR_ID_DU_MEMBRE = 4;
    public static final int RECHERCH_VOIR_TACHE_PAR_STATUS = 5;
    public static final int QUITTER_LE_PROGRAMME = 6;
    
    public static final int ANNULER_ACTION = -1;        
    
    private static Scanner sc = new Scanner(System.in);

    public static void showUserMenu() {
                String saperate = "\n------------------------------------------------------";
                StringBuilder description = new StringBuilder();
                description.append(saperate);
                description.append("\n\tMENU PRINCIPAL FAITES VOTRE CHOIX");
                description.append(saperate);
                description.append("\n| 1. Gestion des tâches");
                description.append("\n| 2. Gestion des membres");
                description.append("\n| 3. Assigner une tâche à un membre");
                description.append("\n| 4. Rechercher et afficher les tâches assignées à un membre (par son ID)");
                description.append("\n| 5. rechercher et afficher les tâches ()");
                description.append("\n| 6. Enregistrer et Quitter le programme ");
                System.out.println(description);
    }
    public static void showTaskStatusMenu() {
                String saperate = "\n------------------------------------------------------";
                StringBuilder description = new StringBuilder();
                description.append(saperate);
                description.append("\n\tMENU ETAT DES TACHES: CHOISISSEZ");
                description.append(saperate);
                description.append("\n|1. Nouvelle (Disponible)");
                description.append("\n|2. En cours");
                description.append("\n|3. Terminée");
                description.append("\n|4. Supprimée");
                System.out.println(description);
    }

    public static void showMenuModifyTask() {        
                String saperate = "\n------------------------------------------------------";
                StringBuilder description = new StringBuilder();
                description.append(saperate);
                description.append("\n\tMENU TACHE: CHOISISSEZ");
                description.append(saperate);
                description.append("\n| 1. CREER");
                description.append("\n| 2. MODIFIER");
                description.append("\n| 3. SUPPRIMER");
                description.append("\n| 4. AJOUTER");
                description.append("\n| 5. ANNULER");
                System.out.println(description);
    }
     
    public static void showMenuModifyMember() {        
        String saperate = "\n------------------------------------------------------";
        StringBuilder description = new StringBuilder();
        description.append(saperate);
        description.append("\n\tMENU MEMBRE: CHOISISSEZ");
        description.append(saperate);
        description.append("\n| 1. CREER");
        description.append("\n| 2. MODIFIER");
        description.append("\n| 3. SUPPRIMER");
        description.append("\n| 4. AJOUTER");
        description.append("\n| 5. ANNULER");
        System.out.println(description);
    }
    
    public static int chooseUserMenu() {
        return chooseMenu(1, 6);
    }

    public static int chooseTaskStatusMenu() {
        return chooseMenu(1, 4);
    }

    public static int chooseMenuModify() {
        return chooseMenu(1, 5);
    }
    
    public static int chooseMenu(int start, int end) {
        int choice = end;
        boolean isChooseAgain;

        do {
            System.out.print("\nENTREZ VOTRE CHOIX <" + start + " -> " + end + "> :");
            isChooseAgain = false;
            try {                                
                choice = Integer.parseInt(sc.nextLine());                
                if (choice < start || choice > end) {
                    isChooseAgain = true;
                }
            } catch (Exception e) {
                isChooseAgain = true;
            }
            if (isChooseAgain) {
                System.out.println("\nMAUVAIS CHOIX, S'il vous plait faites votre choix encore!");
            }
        } while (isChooseAgain);

        return choice;
    }
    
    /**
     * 
     * @param start
     * @param end
     * @return -1 if cancel action
     */
    public static int chooseCancellableMenu(int start, int end) {
        int choice = end;
        boolean isChooseAgain;

        do {
            System.out.print("\nENTRER VOTRE CHOIX: ");
            isChooseAgain = false;
            try {                                
                String query = sc.nextLine();
                if (query.equals("")) {
                    choice = ANNULER_ACTION;
                    break;
                }
                choice = Integer.parseInt(query);                
                if (choice < start || choice > end) {
                    isChooseAgain = true;
                }
            } catch (Exception e) {
                isChooseAgain = true;
            }
            if (isChooseAgain) {
                System.out.println("\nMAUVAIS CHOIX, S'il vous plait faites votre choix encore!");
            }
        } while (isChooseAgain);

        return choice;
    }
}
