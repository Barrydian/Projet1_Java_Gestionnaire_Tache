/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.team.app.entities;

import com.team.app.enumeration.Etats;
import java.io.Serializable;

/**
 *
 * @author MyPC
 */
public class Tache implements Serializable {

    private int id;
    private String nom;
    private String description;
    private Etats statut;
    private Membre membre;

    public Tache() {
    }

    public Tache(int id, String nom, String description) {
        this(id, nom, description, Etats.DISPONIBLE);
    }

    public Tache(int id, String name, String description, Etats status) {
        this.id = id;
        this.nom = name;
        this.description = description;
        this.statut = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return nom;
    }

    public void setName(String name) {
        this.nom = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Etats getStatus() {
        return statut;
    }

    public void setStatus(Etats status) {
        this.statut = status;
    }

    public Membre getMember() {
        return membre;
    }

    public void setMember(Membre member) {
        this.membre = member;
    }

    @Override
    public String toString() {
        String saperate = "\n------------------------------------";
        if (membre != null) {
            return saperate + "\nID: " + id
                            + "\nNom: " + nom
                            + "\nDescription: " + description
                            + "\nStatut: " + statut
                            + "\nMembre associé à cette tâche: " + membre.toString() + "\n";
        }
        return saperate + "\nID: " + id
                            + "\nNom: " + nom
                            + "\nDescription: " + description
                            + "\nStatut: " + statut + "\n";
    }
}
