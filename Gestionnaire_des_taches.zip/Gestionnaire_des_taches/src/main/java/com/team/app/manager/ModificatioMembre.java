/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.team.app.manager;

import com.team.app.entities.Menu;
import com.team.app.enumeration.Operation;
import com.team.app.enumeration.Resultats;
import com.team.app.enumeration.AtributMembre;
import java.util.Scanner;

/**
 *
 * @author MyPC
 */
public class ModificatioMembre {

    private static Scanner sc = new Scanner(System.in);
    private GererMembre memberManager;

    public ModificatioMembre(GererMembre memberManager) {
        this.memberManager = memberManager;
    }

    public void modifyMember() {
        int choice;
        Menu.showMenuModifyMember();
        choice = Menu.chooseMenuModify();
        if (choice == Menu.MODIFIER_QUITTER) {
            System.out.println("\nAnnuler modifier <CREER, SUPPRIMER, AJOUTER, MODIFIER> Membre");
            return;
        }
        serveModifyMember(choice);
    }

    private void serveModifyMember(int choice) {
        switch (choice) {
            case Menu.MODIFIER_CREATION:
                System.out.print("\nCréer un membre:");
                createNewMember();
                break;

            case Menu.MODIFIER_SUPPRESSION:
                deleteMemberById();
                break;

            case Menu.MODIFIER_EDITION:
                editMemberById();
                break;

            case Menu.MODIFIER_AJOUT:
                addMemberById();
                break;

            default:
                System.out.println("Echec de la modification du membre");
                break;
        }
    }

    private void createNewMember() {
        boolean isInDelete;
        do {
            boolean result = memberManager.creer();
            if (result) {
                notifyResult(Operation.CREATION, Resultats.REUSSIE);
            } else {
                notifyResult(Operation.CREATION, Resultats.ECHEC);
            }
            isInDelete = askContinueCreate();
        } while (isInDelete);
    }

    private boolean askContinueCreate() {
        System.out.print("\nVoulez-vous continuerla création des membres? <O/N>: ");
        String query = sc.nextLine();
        boolean isInDelete = query.equalsIgnoreCase("O");
        return isInDelete;
    }

    private void deleteMemberById() {
        boolean isInDelete;
        do {
            memberManager.displayAllMember();
            int id = getDeleteMemberId();
            if (id != Menu.ANNULER_ACTION) {
                boolean isSuccess = memberManager.supprimer(id);
                if (isSuccess) {
                    displayMemberAfterDeleted();
                    notifyResult(Operation.SUPPRESSION, Resultats.REUSSIE);
                } else {
                    notifyResult(Operation.SUPPRESSION, Resultats.ECHEC);
                }
                isInDelete = askContinueDelete();
            } else {
                notifyResult(Operation.SUPPRESSION, Resultats.ANNULEE);
                isInDelete = false;
            }
        } while (isInDelete);

    }

    private int getDeleteMemberId() {
        System.out.println("\nTapez entrée si vous souhaitez annuler");
        System.out.println("Tapez l'ID du membre pour supprimer");
        int id = Menu.chooseCancellableMenu(1, memberManager.getTotalMember());
        return id;
    }

    private void displayMemberAfterDeleted() {
        System.out.print("\nTapez entrée pour afficher la liste de membre après la suppression");
        sc.nextLine();
        memberManager.displayAllMember();
    }

    private boolean askContinueDelete() {
        System.out.print("\nVoulez-vous continuer la suppression des membres?<O/N>: ");
        String query = sc.nextLine();
        boolean isInDelete = query.equalsIgnoreCase("O");
        return isInDelete;
    }

    private void editMemberById() {
        boolean isInEdit;
        do {
            memberManager.displayAllMember();
            int id = getMemberIdToEdit();
            if (id != Menu.ANNULER_ACTION) {
                boolean isSuccess = memberManager.modifier(id);
                if (isSuccess) {
                    displayMemberAfterEdit(id);
                    notifyResult(Operation.MODIFICATION, Resultats.REUSSIE);
                } else {
                    notifyResult(Operation.MODIFICATION, Resultats.ECHEC);
                }
                isInEdit = askContinueEdit();
            } else {
                notifyResult(Operation.MODIFICATION, Resultats.ANNULEE);
                isInEdit = false;
            }
        } while (isInEdit);
    }

    private void addMemberById() {
        boolean isSuccess = memberManager.Ajouter();
        if (isSuccess) {
            notifyResult(Operation.AJOUT, Resultats.REUSSIE);
        } else {
            notifyResult(Operation.AJOUT, Resultats.ECHEC);
        }
    }

    private int getMemberIdToEdit() {
        System.out.println("\nTapez entrée pour annuler");
        System.out.println("Tapez l'ID du membre à modifier");
        int id = Menu.chooseCancellableMenu(1, memberManager.getTotalMember());
        return id;
    }

    private void displayMemberAfterEdit(int id) {
        System.out.print("\nTapez entrée pour afficher le membre après modification");
        sc.nextLine();
        //result true means we have a member with the id to avoid memberManager.getMemberById(id) be null
        System.out.println(memberManager.getMemberById(id).toString());
    }

    private boolean askContinueEdit() {
        System.out.print("\nVoulez-vous continuer la modification des membres?<O>: ");
        String query = sc.nextLine();
        boolean isInDelete = query.equalsIgnoreCase("O");
        return isInDelete;
    }

    public void notifyResult(Operation action, Resultats result) {
        System.out.println(action + " " + result);
    }

    public void notifyResult(Operation action, AtributMembre attr, Resultats result) {
        System.out.println(action + " " + attr + " " + result);
    }
}
