/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.team.app.entities;

/**
 *
 * @author Admin
 */
public class Enumeration {
    public enum AtributMembre {
    ID, NOM
}
    public enum AtributTache {
    ID, NOM, DESCRIPTION, ETAT, MEMBRE
}
    public enum Etats {
    DISPONIBLE, EN_COURS, TERMINE
} 
    public enum Operation {
    CREATION, MODIFICATION, SUPPRESSION, AJOUT, ASSIGNATION, AFFICHER, ACTION_USER
}
 public enum Resultats {
    REUSSIE, ECHEC, ANNULEE
} 
}
