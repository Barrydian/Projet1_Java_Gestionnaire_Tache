/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.team.app.manager;

import com.team.app.entities.Menu;
import com.team.app.enumeration.Operation;
import com.team.app.enumeration.Resultats;
import com.team.app.enumeration.AtributTache;
import java.util.Scanner;

/**
 *
 * @author MyPC
 */
public class ModificationTaches {

    private static Scanner sc = new Scanner(System.in);
    private GererTaches gererTache;

    public ModificationTaches(GererTaches taskManager) {
        this.gererTache = taskManager;
    }

    public void modifyTask() {
        int choice;
        Menu.showMenuModifyTask();
        choice = Menu.chooseMenuModify();
        if (choice == Menu.MODIFIER_QUITTER) {
            System.out.println("\nAnnuler modifier <CREER, SUPPRIMER, AJOUTER, MODIFIER> Tache");
            return;
        }
        serveModifyTask(choice);
    }

    private void serveModifyTask(int choice) {
        switch (choice) {
            case Menu.MODIFIER_CREATION:
                System.out.print("\nCreation d'une tâche:");
                createNewTask();
                break;

            case Menu.MODIFIER_SUPPRESSION:
                deleteTaskById();
                break;

            case Menu.MODIFIER_EDITION:
                editTaskById();
                break;

            case Menu.MODIFIER_AJOUT:
                addTaskById();
                break;

            default:
                System.out.println("echec de la modification de la tache");
                break;
        }
    }

    private void createNewTask() {
        boolean isInDelete;
        do {
            boolean result = gererTache.creer();
            if (result) {
                notifyResult(Operation.CREATION, Resultats.REUSSIE);
            } else {
                notifyResult(Operation.CREATION, Resultats.ECHEC);
            }
            isInDelete = askContinueCreate();
        } while (isInDelete);
    }

    private boolean askContinueCreate() {
        System.out.print("\nVoulez-vous continuer la création des tâches?<O/N>: ");
        String query = sc.nextLine();
        boolean isInDelete = query.equalsIgnoreCase("O");
        return isInDelete;
    }

    private void deleteTaskById() {
        boolean isInDelete;
        do {
            gererTache.displayAllTask();
            int id = getDeleteTaskId();
            if (id != Menu.ANNULER_ACTION) {
                boolean isSuccess = gererTache.supprimer(id);
                if (isSuccess) {
                    displayTaskAfterDeleted();
                    notifyResult(Operation.SUPPRESSION, Resultats.REUSSIE);
                } else {
                    notifyResult(Operation.SUPPRESSION, Resultats.ECHEC);
                }
                isInDelete = askContinueDelete();
            } else {
                notifyResult(Operation.SUPPRESSION, Resultats.ANNULEE);
                isInDelete = false;
            }
        } while (isInDelete);

    }

    private int getDeleteTaskId() {
        System.out.println("\nTapez entrée si vous souhaitez annuler");
        System.out.println("Tapez l'ID de la tache à supprimer");
        int id = Menu.chooseCancellableMenu(1, gererTache.getTotalTask());
        return id;
    }

    private void displayTaskAfterDeleted() {
        System.out.print("\nTapez entrée pour afficher la liste des taches apres supression");
        sc.nextLine();
        gererTache.displayAllTask();
    }

    private boolean askContinueDelete() {
        System.out.print("\nVoulez-vous continuer la suppresion des tâches?<o/n>: ");
        String query = sc.nextLine();
        boolean isInDelete = query.equalsIgnoreCase("O");
        return isInDelete;
    }

    private void editTaskById() {
        boolean isInEdit;
        do {
            gererTache.displayAllTask();
            int id = getTaskIdToEdit();
            if (id != Menu.ANNULER_ACTION) {
                boolean isSuccess = gererTache.modifier(id);
                if (isSuccess) {
                    displayTaskAfterEdit(id);
                    notifyResult(Operation.MODIFICATION, Resultats.REUSSIE);
                } else {
                    notifyResult(Operation.MODIFICATION, Resultats.ECHEC);
                }
                isInEdit = askContinueEdit();
            } else {
                notifyResult(Operation.MODIFICATION, Resultats.ANNULEE);
                isInEdit = false;
            }
        } while (isInEdit);
    }

    private void addTaskById() {
        boolean isSuccess = gererTache.Ajouter();
        if (isSuccess) {
            notifyResult(Operation.AJOUT, Resultats.REUSSIE);
        } else {
            notifyResult(Operation.AJOUT, Resultats.ECHEC);
        }
    }

    private int getTaskIdToEdit() {
        System.out.println("\nTapez entrée pour annuler la modification de taches");
        System.out.println("Tapez l'ID de la tâche à modifier");
        int id = Menu.chooseCancellableMenu(1, gererTache.getTotalTask());
        return id;
    }

    private void displayTaskAfterEdit(int id) {
        System.out.print("\nTapez entrée pour afficher la tâche modifiée");
        sc.nextLine();
        //result true means we have a task with the id to avoid taskManager.getTaskById(id) be null
        System.out.println(gererTache.getTaskById(id).toString());
    }

    private boolean askContinueEdit() {
        System.out.print("\nVoulez-vous continuer la modification des tâches?<O/N>: ");
        String query = sc.nextLine();
        boolean isInDelete = query.equalsIgnoreCase("O");
        return isInDelete;
    }

    public void notifyResult(Operation action, Resultats result) {
        System.out.println(action + " " + result);
    }

    public void notifyResult(Operation action, AtributTache attr, Resultats result) {
        System.out.println(action + " " + attr + " " + result);
    }
}
