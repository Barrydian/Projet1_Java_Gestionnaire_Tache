/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.team.app.manager;

import com.team.app.entities.Membre;
import com.team.app.entities.Menu;
import com.team.app.entities.Tache;
import com.team.app.enumeration.Operation;
import com.team.app.enumeration.Resultats;
import com.team.app.enumeration.Etats;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author MyPC
 */
public class GererUtilisateurUtil {

    private static Scanner sc = new Scanner(System.in);
    private static final GererMembre memberManager = GererMembre.getInstance();
    private static final GererTaches taskManager = GererTaches.getInstance();

    public static void modifyTask() {
        ModificationTaches taskModification = new ModificationTaches(taskManager);
        taskModification.modifyTask();
    }

    public static void modifyMember() {
        ModificatioMembre memberModification = new ModificatioMembre(memberManager);
        memberModification.modifyMember();
    }

    public static void assignTaskToMember() {
        if (taskManager.getTotalTask() == 0) {
            System.out.println("Have no task to choose");
            return;
        }
        showAllTask();
        int taskId = choiceTaskId();
        if (taskId != Menu.ANNULER_ACTION) {
            //task get here cannot be null because of taskId always valid
            Tache task = taskManager.getTaskById(taskId);
            if (task.getStatus() == Etats.DISPONIBLE) { 
                if (memberManager.getTotalMember() == 0) {
                    System.out.println("Have no member to choose");
                    return;
                }
                showAllMember();
                int memberId = choiceMemberId();
                if (memberId != Menu.ANNULER_ACTION) {
                    //member get here cannot be null because of taskId always valid
                    Membre member = memberManager.getMemberById(memberId);
                    task.setMember(member);
                    task.setStatus(Etats.EN_COURS);
                    System.out.println(Operation.ASSIGNATION + " " + Resultats.REUSSIE);
                    showTaskBeAssigned(task);
                } else {
                    System.out.println(Operation.ASSIGNATION + " " + Resultats.ANNULEE);
                }
            }
        }

    }

    private static void showAllTask() {
        System.out.print("\nTapez entrée pour afficher toutes les tâches:");
        sc.nextLine();
        taskManager.displayAllTask();
    }

    private static void showAllMember() {
        System.out.print("\nTapez entrée pour afficher tous les membres:");
        sc.nextLine();
        memberManager.displayAllMember();
    }

    private static void showTaskBeAssigned(Tache task) {
        System.out.print("\nTapez entrée pour afficher toutes les tâches assignées:");
        sc.nextLine();
        System.out.println(task.toString());
    }

    private static int choiceTaskId() {
        System.out.println("Tapez entrée si vous souhaitez annuler l'opération");
        System.out.println("Tapez l'ID de la tâche que vous souhaitez assigner à un membre");        
        int taskId = Menu.chooseMenu(1, taskManager.getTotalTask());
        return taskId;
    }

    private static int choiceMemberId() {
        System.out.println("Tapez entrée si vous souhaitez annuler l'opération");
        System.out.println("Tapez l'ID du membre à qui vous souhaitez assigner cette tâche");
        int memberId = Menu.chooseMenu(1, memberManager.getTotalMember());
        return memberId;
    }

    public static void displayAllTaskByMemberId() {
        showAllMember();
        System.out.println("Tapez l'ID du membre dont vous souhaitez voir les tâches");
        int memberId = Menu.chooseMenu(1, memberManager.getTotalMember());
        viewAllTaskByMemberId(memberId);
    }

    private static void viewAllTaskByMemberId(int id) {
        List<Tache> listTask = taskManager.findAllTaskByMemberId(id);
        for (Tache task : listTask) {
            System.out.println(task.toString());
        }
    }

    public static void displayAllTaskByStatus() {
        Menu.showTaskStatusMenu();
        System.out.print("\nTapez l'etat de la tâche");
        int choice = Menu.chooseTaskStatusMenu();
        Etats status = getStatusByChoice(choice);
        List<Tache> listTask = taskManager.findAllTaskByStatus(status);
        for (Tache task : listTask) {
            System.out.println(task.toString());
        }
    }

    private static Etats getStatusByChoice(int choice) {
        switch (choice) {
            case Menu.TACHE_STATUT_NEW :
                return Etats.DISPONIBLE;

            case Menu.STATUS_TACHE_EN_COURS:
                return Etats.EN_COURS;

            case Menu.TACHE_STATUT_TERMINER:
                return Etats.TERMINE;

            case Menu.TACHE_STATUT_QUITTER:
                System.out.println(Operation.AFFICHER + " " + Resultats.ANNULEE);
                return null;

            default:
                return null;
        }
    }
}
