/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.team.app.manager;

import com.team.app.entities.Membre;
import com.team.app.entities.Menu;
import com.team.app.entities.Tache;
import com.team.app.enumeration.Resultats;
import com.team.app.enumeration.Etats;
import com.team.app.enumeration.AtributTache;
import com.team.app.fileio.LectureEcriture;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javafx.concurrent.Task;

/**
 *
 * @author MyPC
 */
public class GererTaches implements GererOperations {

    private static int id = 1;
    private Scanner sc = new Scanner(System.in);
    private final List<Tache> mListTask = LectureEcriture.getListTaskFromFile();
    private final List<Tache> mListCreatedTask = new ArrayList<>();
    private final static GererTaches TaskManager = new GererTaches();

    public static GererTaches getInstance() {
        return TaskManager;
    }

    private GererTaches() {
    }

    @Override
    public boolean creer() {
        Tache task = makeNewTask();
        mListCreatedTask.add(task);
        return true;
    }

    private Tache makeNewTask() {
        System.out.print("\nTapez le nom de la tâche: ");
        String nom = sc.nextLine();
        System.out.print("Tapez la description: ");
        String des = sc.nextLine();
        return new Tache(id++, nom, des);
    }

    @Override
    public boolean modifier(int id) {
        boolean result = true;
        AtributTache[] taskAttributes = new AtributTache[]{AtributTache.NOM, AtributTache.ETAT, AtributTache.DESCRIPTION, AtributTache.MEMBRE};
        int numMis = taskAttributes.length;
        Tache task = findTaskById(id);
        if (task != null) {
            for (int i = 0; i < numMis; i++) {
                boolean isInEdit;
                do {
                    Resultats captureResult = editAttribute(task, taskAttributes[i], null);
                    if (captureResult == Resultats.ANNULEE) {
                        break;
                    }
                    isInEdit = askChangeAttributeAgain(taskAttributes[i]);
                } while (isInEdit);
            }
        } else {
            result = false;
        }
        return result;
    }

    private boolean askChangeAttributeAgain(AtributTache attr) {
        System.out.print("Changer " + attr + " encore <O/N>: ");
        String querry = sc.nextLine();
        boolean isInEdit = querry.equalsIgnoreCase("O");
        return isInEdit;
    }

    private Resultats editAttribute(Tache task, AtributTache attr, Membre member) {
        Resultats result = Resultats.ECHEC;
        switch (attr) {
            case NOM:
                System.out.println("\nTapez entrée pour annuler la modification du nom");
                System.out.print("Tapez le nouveau nom de la tâche: ");
                String newName = sc.nextLine();
                result = editName(task, newName);
                break;

            case DESCRIPTION:
                System.out.println("\nTapez entrée pour annuler la modification de la description");
                System.out.print("Tapez la nouvelle description : ");
                String newDes = sc.nextLine();
                result = editDescription(task, newDes);
                break;

            case ETAT:
                System.out.println("\nChanger l'état de la tâche");
                Menu.showTaskStatusMenu();
                int choice = Menu.chooseTaskStatusMenu();
                result = setNewStatus(task, choice);
                break;

            case MEMBRE:
                result = setNewMember(task, member);
                break;

            default:
                System.out.println("Modification de la tâche annulée");
                break;
        }
        return result;
    }

    private Resultats editName(Tache task, String newName) {
        //cannot be failed
        Resultats result = Resultats.ANNULEE;
        if (!newName.equals("")) {
            task.setName(newName);
            result = Resultats.REUSSIE;
        }
        return result;
    }

    private Resultats editDescription(Tache task, String newDes) {
        //cannot be failed
        Resultats result = Resultats.ANNULEE;
        if (!newDes.equals("")) {
            task.setDescription(newDes);
            result = Resultats.REUSSIE;
        }
        return result;
    }

    private Resultats setNewStatus(Tache task, int choice) {
        Resultats result = Resultats.REUSSIE;
        switch (choice) {
            case Menu.TACHE_STATUT_NEW:
                task.setStatus(Etats.DISPONIBLE);
                break;

            case Menu.STATUS_TACHE_EN_COURS:
                task.setStatus(Etats.EN_COURS);
                break;

            case Menu.TACHE_STATUT_TERMINER:
                task.setStatus(Etats.TERMINE);
                break;

            case Menu.TACHE_STATUT_QUITTER:
                result = Resultats.ANNULEE;
                break;

            default:
                result = Resultats.ECHEC;
                break;
        }
        return result;
    }

    private Resultats setNewMember(Tache task, Membre member) {
        if (member == null) {
            return Resultats.ECHEC;
        }
        Resultats result = Resultats.ECHEC;
        if (!isAssignedToTask(member)) {
            task.setMember(member);
            result = Resultats.REUSSIE;
        }
        return result;
    }

    private boolean isAssignedToTask(Membre member) {
        if (member == null) {
            return false;
        }
        Membre assignedMember;
        for (Tache task : mListTask) {
            assignedMember = task.getMember();
            if (assignedMember != null && assignedMember.equals(member)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean supprimer(int id) {
        boolean result;
        Tache task = findTaskById(id);
        if (task != null) {
            mListTask.remove(task);
            result = true;
        } else {
            result = false;
        }
        return result;
    }

    private Tache findTaskById(int id) {
        for (Tache task : mListTask) {
            if (task.getId() == id) {
                return task;
            }
        }
        return null;
    }

    @Override
    public boolean Ajouter() {
        boolean isEmptyTask = displayListCreateTask();
        //id always exist to make task not null
        if (!isEmptyTask) {
            int id = chooseCreatedTaskById();
            Tache task = findCreateTaskById(id);
            mListCreatedTask.remove(task);
            mListTask.add(task);
        }
        return true;
    }

    private boolean displayListCreateTask() {
        boolean isEmptyTask = mListCreatedTask.isEmpty();
        if (isEmptyTask) {
            System.out.println("\nAucune tâche n'est créee");
        } else {
            System.out.println("\nListe des tâches crées");
            for (Tache task : mListCreatedTask) {
                System.out.println(task.toString());
            }
        }
        return isEmptyTask;
    }

    private int chooseCreatedTaskById() {
        System.out.println("Choisir une tâche par son ID");
        Tache firstTask = mListCreatedTask.get(0);
        Tache lastTask = mListCreatedTask.get(mListCreatedTask.size() - 1);
        int id = Menu.chooseMenu(firstTask.getId(), lastTask.getId());       
        return id;
    }

    private Tache findCreateTaskById(int id) {
        for (Tache task : mListCreatedTask) {
            if (task.getId() == id) {
                return task;
            }
        }
        return null;
    }

    public void displayAllTask() {
        for (Tache task : mListTask) {
            System.out.println(task.toString());
        }
    }

    public List<Tache> findAllTaskByMemberId(int id) {
        List<Tache> list = new ArrayList<>();
        Membre member;
        for (Tache task : mListTask) {
            member = task.getMember();
            if (member != null && member.getId() == id) {
                list.add(task);
            }
        }
        return list;
    }

    public List<Tache> findAllTaskByStatus(Etats status) {
        List<Tache> list = new ArrayList<>();
        if (status == null) {
            return list;
        }
        for (Tache task : mListTask) {
            if (task.getStatus() == status) {
                list.add(task);
            }
        }
        return list;
    }

    public Tache getTaskById(int id) {
        for (Tache task : mListTask) {
            if (task.getId() == id) {
                return task;
            }
        }
        return null;
    }

    public int getTotalTask() {
        return mListTask.size();
    }

    public List<Tache> getmListTask() {
        return mListTask;
    }

}
