
import com.team.app.manager.GererUtilisateur;
public class Main {
    public static void main(String[] args) {
        GererUtilisateur userManager = new GererUtilisateur();
        userManager.runSoftware();
    }
}
